#ifndef _NEW_CONSTANTS_
	#define _NEW_CONSTANTS_

	#define	SQL_DONT_CLOSE	0xf8f8
#endif

long constant(char *name);
